﻿using System;

namespace LtmApp.Web.Exceptions
{
    public class DepartmentException : Exception
    {
        public DepartmentException(string message) : base(message)
        {

        }
    }
}
