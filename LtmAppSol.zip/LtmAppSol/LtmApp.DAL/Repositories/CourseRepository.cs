﻿using LtmApp.DAL.Context;
using LtmApp.DAL.Entities;
using LtmApp.DAL.Interfaces;
using LtmApp.DAL.Models;
using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;

namespace LtmApp.DAL.Repositories
{
    public class CourseRepository: ICourseRepository
    {
        private readonly LtmContext _ltmContext;
        private readonly ILogger<CourseRepository> _illooger;

        public CourseRepository(LtmContext ltmContext, ILogger<CourseRepository> illooger)
        {
            _ltmContext = ltmContext;
            _illooger = illooger;
        }   


        public bool Exists(string title)
        {
            return _ltmContext.Courses.Any(c => c.Title == title);
        }

        public List<CourseDepartmentModel> GetAll()
        {

            var courses = _ltmContext.Courses.Select(cd => new CourseDepartmentModel()
            {
                CourseID = cd.CourseID,
                Credits = cd.Credits,
                Title = cd.Title,
                CreationDate = cd.CreationDate,
                DepartmentID = cd.DepartmentID
            }).ToList();

            return courses;
        }

        public Course GetById(int ID)
        {
            return _ltmContext.Courses.Find(ID);
        }

        public void Remove(Course course)
        {
            try
            {
                Course CourseToRemove = this.GetById(course.CourseID);
                CourseToRemove.DeletedDate = DateTime.Now;
                CourseToRemove.Deleted = true;
                CourseToRemove.UserDeleted = course.UserDeleted;

               this._ltmContext.Courses.Remove(CourseToRemove);
            }
            catch (Exception ex)
            {

                _illooger.LogError($"Error removiendo el curso {ex.Message}", ex.ToString());
            }
        }

        public void Save(Course course)
        {
            try
            {
                Course CourseToSave = new Course();
                CourseToSave.CreationDate = DateTime.Now;
                CourseToSave.Title= course.Title;
                CourseToSave.CreationUser = course.CreationUser;

                _ltmContext.Courses.Add(CourseToSave);
            }
            catch (Exception ex)
            {

                _illooger.LogError($"Eror guardando el curso {ex.Message}", ex.ToString());
            }
        }

        public void Update(Course course)
        {
            try
            {
                Course CourseToUpdate = this.GetById(course.CourseID);
                CourseToUpdate.Title = course.Title;
                CourseToUpdate.CreationDate = DateTime.Now;
                CourseToUpdate.ModifyDate = DateTime.Now;

                _ltmContext.Courses.Update(CourseToUpdate);

            }
            catch (Exception ex)
            {

                _illooger.LogError($"Eror guardando el curso {ex.Message}", ex.ToString());
            }
        }
    }
}
